const {ChartJSNodeCanvas} = require("chartjs-node-canvas");

const width = 600;
const height = 400;
const chartJSNodeCanvas = new ChartJSNodeCanvas({width, height});

async function generateChartImage(data, type) {
  const labels = [
    "Минут на поле",
    "Ср. макс. скорость",
    "Ср. макс. ускорение",
    "Ср. макс. торможение",
    "Дист. Z4-Z5 (м/мин)",
    "Метабол. сила",
  ];
  const values = [
    data.minutes,
    data.avgMaxSpeed,
    data.avgMaxAcc,
    data.avgMaxDec,
    data.z4z5Distance,
    data.metabolicPower,
  ];

  const config = getChartConfig(type, labels, values);
  const image = await chartJSNodeCanvas.renderToBuffer(config);
  return image;
}

function getChartConfig(type, labels, values) {
  const datasets = [
    {
      label: "ASP",
      data: values,
      backgroundColor: "rgba(54, 162, 235, 0.5)",
      borderColor: "rgba(54, 162, 235, 1)",
      borderWidth: 1,
      fill: type === "radar",
    },
  ];

  switch (type) {
    case "bar":
      return {
        type: "bar",
        data: {labels, datasets},
        options: {responsive: true},
      };

    case "radar":
      return {
        type: "radar",
        data: {labels, datasets},
        options: {
          responsive: true,
          elements: {
            line: {borderWidth: 2},
          },
        },
      };

    case "line":
      return {
        type: "line",
        data: {labels, datasets},
        options: {
          responsive: true,
          tension: 0.3,
        },
      };

    default:
      throw new Error(`Неизвестный тип графика: ${type}`);
  }
}

module.exports = {generateChartImage};
