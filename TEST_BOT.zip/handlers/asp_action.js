const {InlineKeyboard, InputFile} = require("grammy");
const {getUser} = require("../services/userService");
const {getAvailableMonths, getAspData} = require("../services/statService");
const {generateChartImage} = require("../utils/chartGenerator");

module.exports = (bot) => {
  // Этап 1: выбор месяца
  bot.callbackQuery(/^stats_asp$/, async (ctx) => {
    const tgId = ctx.from.id;
    const user = await getUser(tgId);

    if (!user || !user.athlete_id) {
      return ctx.answerCallbackQuery({
        text: "❌ Вы ещё не верифицированы. Отправьте /verify_me",
        show_alert: true,
      });
    }

    const months = await getAvailableMonths(user.athlete_id);

    const keyboard = new InlineKeyboard();
    for (const month of months) {
      keyboard.text(month.label, `asp_month_${month.value}`).row();
    }
    keyboard.text("🔙 Назад", "stats_back");

    await ctx.editMessageText("📅 Выберите месяц для ASP:", {
      reply_markup: keyboard,
    });
  });

  // Этап 3: генерация графика
  bot.callbackQuery(/^asp_month_(.+)$/, async (ctx) => {
    const month = ctx.match[1];
    const userId = ctx.from.id;

    await ctx.answerCallbackQuery(); // просто закрывает "часики"
    await ctx.reply("🛠 Генерация графика, подождите...");

    try {
      const user = await getUser(userId);
      if (!user || !user.athlete_id) {
        return ctx.reply("❌ Вы не верифицированы.");
      }
      const aspData = await getAspData(user.athlete_id, month); // ✅
      if (!aspData) {
        return ctx.reply("⚠️ Недостаточно данных для построения графика.");
      }

      //

      const chartType = "radar";
      const imageBuffer = await generateChartImage(aspData, chartType);

      const summary = `
📊 *ASP за ${month}*
🕒 Минут на поле: *${aspData.minutes}*
🚀 Ср. макс. скорость: *${aspData.avgMaxSpeed.toFixed(1)} км/ч*
⚡ Ср. макс. ускорение: *${aspData.avgMaxAcc.toFixed(2)} м/с²*
🛑 Ср. макс. торможение: *${aspData.avgMaxDec.toFixed(2)} м/с²*
📏 Дист. Z4-Z5: *${aspData.z4z5Distance.toFixed(1)} м/мин*
🔥 Метаб. сила: *${aspData.metabolicPower.toFixed(2)} Вт/кг*
`.trim();

      // const keyboard = new InlineKeyboard().text("🔙 Назад", "stats_asp");

      await ctx.replyWithPhoto(new InputFile(imageBuffer), {
        caption: summary,
        parse_mode: "Markdown",
        // reply_markup: keyboard,
      });
    } catch (err) {
      console.error("❌ Ошибка при генерации ASP:", err);
      await ctx.reply("❌ Не удалось построить график. Попробуйте позже.");
    }
  });

  // Возврат на шаг назад
  bot.callbackQuery(/^stats_back$/, async (ctx) => {
    await ctx.editMessageText("🔙 Назад. Вы можете снова вызвать /stats");
  });
};
