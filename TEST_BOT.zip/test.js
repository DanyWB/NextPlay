require("dotenv").config();
const axios = require("axios");

const BASE_API = "https://e05.gpexe.com/api";
const sessionId = 1450108; // ← укажи нужный ID здесь

async function authenticate() {
  const res = await axios.post(`${BASE_API}-token-auth/`, {
    username: process.env.GPEXE_USER,
    password: process.env.GPEXE_PASS,
  });
  return res.data.token;
}

async function fetchAthleteSessionMore(token, sessionId) {
  try {
    const url = `${BASE_API}/athlete_session/${sessionId}/more/`;
    const res = await axios.get(url, {
      headers: {Authorization: `Token ${token}`},
    });

    const more = res.data;

    console.log("\n--- 🔍 ПОЛНЫЙ ОТВЕТ /more/ ---");
    console.dir(more, {depth: null});

    console.log("\n--- 🔍 Проверка интересующих полей ---");

    const fields = {
      average_mp: more?.average_mp,
      power_events_avg_power: more?.power_events_avg_power,
      "max_values.power": more?.max_values?.power?.value,
      average_power_aer: more?.average_power_aer,
      recovery_average_power: more?.recovery_average_power,
    };

    for (const [key, value] of Object.entries(fields)) {
      console.log(`${key}:`, value !== undefined ? value : "⛔ NOT FOUND");
    }
  } catch (err) {
    console.error("❌ Ошибка при запросе:", err.message);
  }
}

(async () => {
  const token = await authenticate();
  await fetchAthleteSessionMore(token, sessionId);
})();
